// 本物のサーバーコード（まねのスプレッドシート上）と本物の画面をつないで、操作を確かめる
const path = require('path');
const fs = require('fs');
const M = require('./gasmock.js');
const { ctx, sheets, props } = M;
const vm = require('vm');
const { chromium, devices } = require('playwright');
const OUT = path.join(__dirname, 'out'); fs.mkdirSync(OUT, { recursive: true });
const LAT = Number(process.env.LAT || 800);
const html = fs.readFileSync(path.join(M.REPO, 'index.html'), 'utf8');

// データを本番に近い量にする
const add = (name, n, mk) => { const d = sheets[name]._data(); const head = d[0]; for (let i = 0; i < n; i++) { const o = mk(i); d.push(head.map(h => (h in o) ? o[h] : '')); } };
add('ToDo', 30, i => ({ 'ID': 'T' + String(100 + i).padStart(4, '0'), 'PJ ID': 'PJ001', '大見出し': ['会場', '集客', '制作'][i % 3], 'ステータス': ['未着手', '進行中', '完了'][i % 3] === '完了' ? '未着手' : ['未着手', '進行中'][i % 2], '小見出し': 'タスク' + i, '締切日': '2026-11-' + String(1 + i % 28).padStart(2, '0'), '担当者': i % 2 ? '田中' : '鈴木' }));
add('当日参加者', 40, i => ({ 'ID': 'G' + String(100 + i).padStart(4, '0'), 'PJ ID': 'PJ001', '氏名': '参加者' + i, '大学': ['A大学', 'B大学'][i % 2], '学年': (1 + i % 4) + '年', '参加状況': '申込' }));
props.set('s:tok', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 1e9 }));
const fresh = () => vm.runInContext('for (const k in MEMO_) delete MEMO_[k]; SS_ = null; TZ_CACHE = "";', ctx);
let REQ = []; let FAILNEXT = 0;
const todoRows = () => { const d = sheets['ToDo']._data(); const h = d[0]; return d.slice(1).filter(r => r[h.indexOf('PJ ID')] === 'PJ001').map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };
const results = []; const ok = (name, cond, info) => { results.push((cond ? '✅ ' : '❌ ') + name + (info ? '  — ' + info : '')); };

async function setup(page) {
  await page.route(/fonts\.googleapis|jsdelivr/, r => r.abort());
  await page.route('https://ypu.test/config.js', r => r.fulfill({ contentType: 'text/javascript', body: "window.YPU_API='https://script.google.com/macros/s/X/exec';" }));
  await page.route('https://ypu.test/', r => r.fulfill({ contentType: 'text/html', body: html }));
  await page.route('https://script.google.com/**', async r => {
    const body = r.request().postData(); const fn = JSON.parse(body).fn; REQ.push(fn);
    await new Promise(res => setTimeout(res, LAT));
    if (FAILNEXT && fn === 'saveRows') { FAILNEXT--; return r.fulfill({ contentType: 'application/json', body: JSON.stringify({ ok: false, error: 'テスト用の失敗' }) }); }
    fresh();
    const out = ctx.doPost({ postData: { contents: body } });
    r.fulfill({ contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: out });
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const idle = async (page) => { await sleep(60); for (let i = 0; i < 80; i++) { const q = await page.evaluate(() => !!document.querySelector('#st .spin') || document.getElementById('netbar').classList.contains('on')); if (!q) return; await sleep(150); } };

(async () => {
  const b = await chromium.launch();
  const errs = [];
  // ---------- PC ----------
  const pc = await b.newPage({ viewport: { width: 1400, height: 900 } });
  pc.on('pageerror', e => errs.push('PC: ' + e.message));
  await setup(pc);
  await pc.goto('https://ypu.test/');
  await pc.evaluate(() => { localStorage.setItem('ypu_token', 'tok'); });
  await pc.goto('https://ypu.test/');
  await pc.waitForSelector('#st .chip'); const loadingChip = await pc.textContent('#st');
  ok('読み込み中に「何をしているか」が見える', /読み込んで/.test(loadingChip), loadingChip.trim());
  await pc.waitForSelector('[data-act="openPj"]');
  await pc.click('[data-act="openPj"]');
  await pc.waitForSelector('[data-act="page"][data-v="ToDo"]'); await idle(pc);
  // ページ移動は待たない（先読み済み）
  REQ = [];
  let t0 = Date.now(); await pc.click('[data-act="page"][data-v="ToDo"]'); await pc.waitForSelector('table[data-tbl="todo"]'); const navMs = Date.now() - t0;
  ok('ToDoページがすぐ開く（先読み）', navMs < 400, navMs + 'ms（サーバー待ち ' + LAT + 'ms）');
  await idle(pc);
  ok('ページ移動の確認は軽い（sync）', REQ.every(f => f === 'sync'), REQ.join(','));
  await pc.click('[data-act="todoStatus"][data-v="すべて"]');

  // 1) 入力 → Tab → 続けて入力：画面は即反映、入力中の文字は消えない
  const first = await pc.getAttribute('table[data-tbl="todo"] tr[data-row]', 'data-row');
  const sub = `input[data-t="todo"][data-f="sub"][data-id="${first}"]`;
  const memo = `input[data-t="todo"][data-f="memo"][data-id="${first}"]`;
  REQ = [];
  await pc.click(sub); await pc.fill(sub, '会場下見を予約'); t0 = Date.now(); await pc.keyboard.press('Tab');
  await pc.keyboard.type('業者に電話済み', { delay: 30 });
  const chip = await pc.textContent('#st');
  ok('保存中も入力を続けられる（ブロックしない）', /保存中/.test(chip) || /保存しました/.test(chip), chip.trim());
  await sleep(LAT + 400);
  ok('保存の結果が返っても入力中の文字が消えない', (await pc.inputValue(memo)) === '業者に電話済み');
  ok('入力中の欄からカーソルが外れない', await pc.evaluate(s => document.activeElement === document.querySelector(s), memo));
  await pc.keyboard.press('Enter'); await idle(pc);
  const tr = todoRows().find(r => r.ID === first);
  ok('2つの欄がスプレッドシートに保存された', tr['小見出し'] === '会場下見を予約' && tr['内容・進捗メモ'] === '業者に電話済み', tr['小見出し'] + ' / ' + tr['内容・進捗メモ']);
  ok('Enterで1つ下の行の同じ列へ移動', await pc.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-f') === 'memo' && document.activeElement.closest('tr').previousElementSibling !== null));
  await pc.keyboard.press('Escape');

  // 2) 行を追加 → すぐ書き込む（まだIDがない行）
  const before = todoRows().length;
  await pc.click('[data-act="addRow"][data-v="会場"]'); await sleep(50);
  const tmpSel = 'input[data-t="todo"][data-f="sub"][data-id^="tmp"]';
  ok('「＋行を追加」で行がすぐ出る', !!(await pc.$(tmpSel)));
  await pc.fill(tmpSel, '新しいタスク'); await pc.keyboard.press('Tab'); await idle(pc);
  const added = todoRows().filter(r => r['小見出し'] === '新しいタスク');
  ok('追加直後に書いた内容も正しく保存', todoRows().length === before + 1 && added.length === 1, '行数 ' + before + '→' + todoRows().length);

  // 3) スプレッドシートから貼り付け（3行×4列：小見出し・メモ・ステータス・開始日。続けて新しい行も）
  const rows3 = await pc.$$eval('table[data-tbl="todo"] tr[data-row]', t => t.map(x => x.getAttribute('data-row')));
  const target = rows3[rows3.length - 2];
  await pc.click(`input[data-t="todo"][data-f="sub"][data-id="${target}"]`);
  const nBefore = todoRows().length;
  await pc.evaluate(t => { const dt = new DataTransfer(); dt.setData('text/plain', t); document.activeElement.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); },
    '貼り付けA\tメモA\t進行中\t2026/11/20\n貼り付けB\tメモB\t進行中\t11/21\n貼り付けC\tメモC\t未着手\t2026-11-22\n');
  await sleep(100); const toastTxt = await pc.textContent('#toast');
  ok('貼り付け結果をお知らせ', /2行を更新、1行を追加/.test(toastTxt), toastTxt.trim());
  await idle(pc);
  const pa = todoRows().filter(r => /^貼り付け/.test(r['小見出し']));
  ok('貼り付けがスプレッドシートに反映（更新2行＋追加1行）', pa.length === 3 && todoRows().length === nBefore + 1 && pa.find(r => r['小見出し'] === '貼り付けB')['開始日'] instanceof Date, pa.map(r => r['小見出し'] + ':' + (r['開始日'] instanceof Date ? 'date' : r['開始日'])).join(' '));
  REQ = [];
  // 4) 行の選択（クリック＋Shift）→ コピー → 削除 → 元に戻す
  await pc.click('[data-act="todoStatus"][data-v="すべて"]');
  const RH = i => pc.locator('table[data-tbl="todo"] td[data-rh]').nth(i);
  await RH(0).click(); await RH(2).click({ modifiers: ['Shift'] });
  ok('Shiftで3行を範囲選択', (await pc.$$('tr.selrow')).length === 3);
  ok('一括操作バーが出る', /3行を選択中/.test(await pc.textContent('.bulk')));
  const copied = await pc.evaluate(() => { const dt = new DataTransfer(); const ev = new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true }); document.dispatchEvent(ev); return dt.getData('text/plain'); });
  ok('Ctrl+C で3行をタブ区切りでコピー', copied.split('\n').length === 3 && copied.split('\n')[0].split('\t').length === 8, JSON.stringify(copied.split('\n')[0]));
  const n0 = todoRows().length;
  await pc.keyboard.press('Delete'); await sleep(50);
  ok('Delete で3行が画面からすぐ消える', (await pc.$$('tr.selrow')).length === 0);
  await idle(pc);
  ok('削除がスプレッドシートに反映（1回の通信で3行）', todoRows().length === n0 - 3 && REQ.filter(f => f === 'deleteRows').length === 1, n0 + '→' + todoRows().length);
  await pc.keyboard.press('Control+z'); await idle(pc);
  ok('Ctrl+Z で削除を元に戻せる', todoRows().length === n0, '→' + todoRows().length);

  // 5) 右クリックメニュー → ステータス変更
  const r5 = await pc.getAttribute('table[data-tbl="todo"] tr[data-row]', 'data-row');
  await pc.click(`tr[data-row="${r5}"] td[data-rh]`, { button: 'right' });
  ok('右クリックでメニュー', !!(await pc.$('.ctx')));
  await pc.screenshot({ path: OUT + '/pc_ctx.png' });
  await pc.click('.ctx button:has-text("完了")'); await idle(pc);
  ok('メニューからステータスを変更', todoRows().find(r => r.ID === r5)['ステータス'] === '完了');

  // 6) 列を選んで一括で空に → 元に戻す
  await pc.click('th[data-colh="fb"]', { modifiers: ['Control'] });
  ok('Ctrl＋見出しで列を選択', (await pc.$$('td.selcol')).length > 3);
  const fbBefore = todoRows().filter(r => r['FBメモ']).length;
  await pc.evaluate(() => document.activeElement && document.activeElement.blur());
  // FBメモに値を入れてから
  await pc.keyboard.press('Escape');
  // 7) 一括操作バー：担当を変える
  await RH(3).click(); await RH(5).click({ modifiers: ['Shift'] });
  const selIds = await pc.$$eval('tr.selrow', x => x.map(t => t.getAttribute('data-row')));
  await pc.fill('[data-bulk="who"]', '木村'); await pc.click('[data-act="bulkWho"]'); await idle(pc);
  ok('一括で担当を変更（3行）', selIds.length === 3 && selIds.every(id => todoRows().find(r => r.ID === id)['担当者'] === '木村'), selIds.join(','));

  // 8) 並べ替え（列のメニュー）
  await pc.click('th[data-colh="end"]', { button: 'right' }); await pc.click('.ctx button:has-text("大きい順")');
  const ends = await pc.$$eval('table[data-tbl="todo"] tr.grp + tr[data-row] input[data-f="end"]', x => x.map(i => i.value));
  ok('並べ替え（締切の降順）', ends.length > 0, ends.slice(0, 3).join(','));
  await pc.screenshot({ path: OUT + '/pc_todo.png' });
  // 8b) 見出しを押すと並べ替え（ステータスは選択肢の順）
  await pc.click('[data-act="todoStatus"][data-v="すべて"]');
  await pc.click('table[data-tbl="todo"] th[data-colh="status"]'); await sleep(50);
  const sts = await pc.$$eval('table[data-tbl="todo"] tbody tr[data-row]', x => x.map(t => t.querySelector('select[data-f="status"]').value));
  const rankOf = v => ['未着手','進行中','完了'].indexOf(v);
  ok('見出しを押すとステータス順に並ぶ（グループの中で）', sts.length > 3 && !!(await pc.$('th[data-colh="status"] .sortmark')), sts.slice(0, 4).join(','));
  await pc.click('table[data-tbl="todo"] th[data-colh="status"]'); await pc.click('table[data-tbl="todo"] th[data-colh="status"]'); await sleep(50);
  ok('3回押すと元の順に戻る', !(await pc.$('th[data-colh="status"] .sortmark')));
  ok('ToDoの列は 小見出し→内容→ステータス の順', (await pc.$$eval('table[data-tbl="todo"] th[data-colh]', x => x.slice(0, 3).map(t => t.getAttribute('data-colh')).join(','))) === 'sub,memo,status');
  ok('絞り込みのタブは すべて→未完了→期限切れ の順', (await pc.$$eval('[data-act="todoStatus"]', x => x.slice(0, 3).map(b => b.getAttribute('data-v')).join(','))) === 'すべて,未完了,期限切れ');
  ok('大見出しの帯に色がつく', await pc.$eval('table[data-tbl="todo"] tr.grp', t => !!t.style.getPropertyValue('--gc')));
  // 8c) ＋ボタンで項目（列）を追加 → 入力 → 保存
  await pc.click('table[data-tbl="todo"] .colplus');
  ok('＋ボタンで項目の管理が開く', !!(await pc.$('.modal [data-llist="cols"]')));
  await pc.fill('#xName', '電話番号'); await pc.click('.modal form[data-form="xAdd"] button[type="submit"]'); await sleep(50);
  ok('項目を足すと表に列が出る', !!(await pc.$('table[data-tbl="todo"] th[data-colh^="x:"]')));
  // 「メモ」を隠す
  await pc.click('.modal input[data-cm="show"][data-v="fb"]'); await sleep(30);
  ok('チェックを外すと列が隠れる', !(await pc.$('table[data-tbl="todo"] th[data-colh="fb"]')));
  await pc.click('.modal [data-act="closeOv"].btn'); await sleep(900); await idle(pc);
  const cfgRow = sheets['表の設定'] && sheets['表の設定']._data().find(r => r[1] === 'todo');
  ok('項目の設定がスプレッドシートに保存', !!cfgRow && /電話番号/.test(cfgRow[2]));
  const xf = await pc.getAttribute('table[data-tbl="todo"] th[data-colh^="x:"]', 'data-colh');
  const xin = pc.locator(`table[data-tbl="todo"] input[data-f="${xf}"]`).first();
  await xin.fill('06-1111-2222'); await xin.press('Enter'); await idle(pc);
  // 8d) メニュー（アコーディオン）とお知らせ（ベル）
  await pc.click('[data-act="drawer"]');
  ok('メニューが開く', !!(await pc.$('.drawer .navgo')));
  await pc.click('.drawer [data-act="acc"][data-v="集客アタック"]');
  ok('メニューの中を開ける（アコーディオン）', !!(await pc.$('.drawer .accb .navsub')));
  await pc.click('.drawer .accb .navsub'); await sleep(100);
  ok('メニューからページへ移動', !!(await pc.$('[data-act="atkKind"]')) && !(await pc.$('.drawer')));
  await pc.click('[data-act="bell"]');
  ok('ベルでお知らせが開く', !!(await pc.$('.bellp')));
  await pc.keyboard.press('Escape');
  await pc.click('[data-act="drawer"]'); await pc.click('.drawer .navgo:has-text("ToDo")'); await sleep(100);
  ok('足した項目に入れた値が保存', sheets['ToDo']._data().some(r => r.some(c => /06-1111-2222/.test(String(c)))));

  // 9) ほかの人が変更 → 自動で反映（30秒ごとの確認）
  fresh(); const other = todoRows()[5].ID;
  ctx.saveRows('tok', 'PJ001', 'todo', [{ id: other, sub: 'ほかの人が直した' }]);
  REQ = [];
  await pc.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await idle(pc); await sleep(200);
  ok('ほかの人の変更が自動で画面に出る', (await pc.$$eval('input[data-f="sub"]', x => x.map(i => i.value))).includes('ほかの人が直した'), REQ.join(','));
  REQ = [];
  await pc.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); await idle(pc);
  fresh(); const same = ctx.sync('tok', 'PJ001', ['todo'], vm.runInContext('ver_("PJ001")', ctx));
  ok('変化がないときの確認はシートを読まない', same.same === true);

  // 10) 保存に失敗 → もう一度
  FAILNEXT = 1;
  const r10 = await pc.getAttribute('table[data-tbl="todo"] tr[data-row]:nth-of-type(3)', 'data-row');
  await pc.fill(`input[data-f="memo"][data-id="${r10}"]`, '失敗テスト'); await pc.keyboard.press('Tab');
  await sleep(LAT + 300);
  ok('保存に失敗したらはっきり出る', /保存できませんでした/.test(await pc.textContent('#st')));
  await pc.screenshot({ path: OUT + '/pc_error.png' });
  await pc.click('[data-act="retry"]'); await idle(pc);
  ok('「もう一度」で保存できる', todoRows().find(r => r.ID === r10)['内容・進捗メモ'] === '失敗テスト');

  // 11) 何も選ばずに表へ貼り付け → 新しい行として追加（メンバー表）
  await pc.click('[data-act="go"][data-v="home"]'); await pc.click('[data-act="page"][data-v="メンバー表"]');
  await pc.waitForSelector('table[data-tbl="guest"]'); await idle(pc);
  const g0 = sheets['当日参加者']._data().length;
  await pc.evaluate(t => { document.activeElement && document.activeElement.blur(); const dt = new DataTransfer(); dt.setData('text/plain', t); document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, '山田 一郎\tC大学\t2年\n川口 花\tD大学\t3年');
  await idle(pc);
  ok('名簿をまとめて貼り付けて追加', sheets['当日参加者']._data().length === g0 + 2);
  await pc.screenshot({ path: OUT + '/pc_members.png', fullPage: false });

  // 12) 列の幅（ドラッグ）がまだ動く
  await pc.evaluate(() => { window.scrollTo(0, 0); document.getElementById('toast').hidden = true; }); await sleep(100);
  const th = await pc.$('table[data-tbl="guest"] th[data-colh="name"]'); const bb = await th.boundingBox();
  await pc.mouse.move(bb.x + bb.width - 1, bb.y + 10); await pc.mouse.down(); await pc.mouse.move(bb.x + bb.width + 120, bb.y + 10, { steps: 4 }); await pc.mouse.up();
  const w2 = (await (await pc.$('table[data-tbl="guest"] th[data-colh="name"]')).boundingBox()).width;
  ok('列の幅をドラッグで変更', w2 > bb.width + 80, Math.round(bb.width) + '→' + Math.round(w2));

  // ---------- スマホ ----------
  const ctxM = await b.newContext({ ...devices['iPhone 13'] });
  const sp = await ctxM.newPage();
  sp.on('pageerror', e => errs.push('SP: ' + e.message));
  await setup(sp);
  await sp.goto('https://ypu.test/'); await sp.evaluate(() => localStorage.setItem('ypu_token', 'tok')); await sp.goto('https://ypu.test/');
  await sp.waitForSelector('[data-act="openPj"]'); await sp.tap('[data-act="openPj"]');
  await sp.waitForSelector('[data-act="page"][data-v="ToDo"]'); await idle(sp);
  await sp.tap('[data-act="page"][data-v="ToDo"]'); await sp.waitForSelector('.sw'); await idle(sp);
  const swipeOn = async (sel, dx) => {
    const box = await (await sp.$(sel)).boundingBox(); const y = box.y + box.height - 12, x0 = box.x + box.width / 2;
    await sp.evaluate(({ sel, x0, y, dx }) => {
      const el = document.querySelector(sel).querySelector('.card .cardhead') || document.querySelector(sel);
      const T = (x) => new Touch({ identifier: 1, target: el, clientX: x, clientY: y });
      el.dispatchEvent(new TouchEvent('touchstart', { touches: [T(x0)], bubbles: true }));
      for (let i = 1; i <= 8; i++) el.dispatchEvent(new TouchEvent('touchmove', { touches: [T(x0 + dx * i / 8)], bubbles: true }));
      el.dispatchEvent(new TouchEvent('touchend', { touches: [], changedTouches: [T(x0 + dx)], bubbles: true }));
    }, { sel, x0, y, dx });
  };
  const sid = await sp.getAttribute('.sw', 'data-sid');
  const st0 = todoRows().find(r => r.ID === sid)['ステータス'];
  await swipeOn(`.sw[data-sid="${sid}"]`, 120); await idle(sp);
  const st1 = todoRows().find(r => r.ID === sid)['ステータス'];
  ok('スマホ：右スワイプでステータスを進める', st0 !== st1, st0 + '→' + st1);
  const n1 = todoRows().length;
  const sidL = await sp.getAttribute('.sw', 'data-sid');
  await swipeOn(`.sw[data-sid="${sidL}"]`, -120); await idle(sp);
  ok('スマホ：左スワイプで削除', todoRows().length === n1 - 1);
  await sp.screenshot({ path: OUT + '/sp_undo_toast.png' });
  await sp.tap('[data-toast]'); await idle(sp);
  ok('スマホ：お知らせの「元に戻す」で復活', todoRows().length === n1);
  // 長押し
  const sid2 = await sp.getAttribute('.sw', 'data-sid');
  await sp.evaluate(sel => { const el = document.querySelector(sel).querySelector('.cardhead'); const r = el.getBoundingClientRect(); const T = new Touch({ identifier: 2, target: el, clientX: r.x + r.width - 40, clientY: r.y + 5 }); el.dispatchEvent(new TouchEvent('touchstart', { touches: [T], bubbles: true })); }, `.sw[data-sid="${sid2}"]`);
  await sleep(700);
  ok('スマホ：長押しでメニュー', !!(await sp.$('.ctx')));
  await sp.screenshot({ path: OUT + '/sp_menu.png' });
  await sp.evaluate(() => document.dispatchEvent(new TouchEvent('touchend', { touches: [], bubbles: true })));
  await sp.keyboard.press('Escape');
  // 左端からスワイプで戻る
  await sp.evaluate(() => { const T = x => new Touch({ identifier: 3, target: document.body, clientX: x, clientY: 400 }); document.body.dispatchEvent(new TouchEvent('touchstart', { touches: [T(8)], bubbles: true })); for (let i = 1; i <= 6; i++) document.body.dispatchEvent(new TouchEvent('touchmove', { touches: [T(8 + i * 25)], bubbles: true })); document.body.dispatchEvent(new TouchEvent('touchend', { touches: [], bubbles: true })); });
  await sleep(300);
  ok('スマホ：画面の左端から右へスワイプで戻る', !!(await sp.$('[data-act="page"][data-v="ToDo"]')));
  await sp.screenshot({ path: OUT + '/sp_home.png' });

  console.log(results.join('\n'));
  console.log(errs.length ? 'ページのエラー:\n' + errs.join('\n') : 'ページのエラー: なし');
  process.exitCode = (results.some(r => r.startsWith('❌')) || errs.length) ? 1 : 0;
  await b.close();
})().catch(e => { console.log(results.join('\n')); console.error('止まった:', e.message); process.exit(1); });
