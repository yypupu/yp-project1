// 「追加」と「受付」の反応：長い一覧（300人）で、押してから画面に出るまで
const path = require('path'), fs = require('fs'), vm = require('vm');
const M = require('./gasmock.js'); const { ctx, sheets, props } = M;
const { chromium, devices } = require('playwright');
const html = fs.readFileSync(path.join(M.REPO, 'index.html'), 'utf8');
const add = (name, n, mk) => { const d = sheets[name]._data(); const head = d[0]; for (let i = 0; i < n; i++) { const o = mk(i); d.push(head.map(h => (h in o) ? o[h] : '')); } };
add('当日参加者', 300, i => ({ 'ID': 'G' + String(100 + i).padStart(4, '0'), 'PJ ID': 'PJ001', '氏名': '参加者' + i, '大学': 'A大学', '学年': '3年', '参加状況': '申込' }));
add('ToDo', 200, i => ({ 'ID': 'T' + String(100 + i).padStart(4, '0'), 'PJ ID': 'PJ001', '大見出し': '群' + (i % 3), 'ステータス': '未着手', '小見出し': 'タスク' + i, '締切日': '2026-11-20', '担当者': '鈴木' }));
props.set('s:tok', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 1e9 }));
const fresh = () => vm.runInContext('for (const k in MEMO_) delete MEMO_[k]; SS_ = null; TZ_CACHE = "";', ctx);
const rows = n => { const d = sheets[n]._data(); const h = d[0]; return d.slice(1).filter(r => r.some(c => c !== '')).map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = []; const ok = (n, c, i) => results.push((c ? '✅ ' : '❌ ') + n + (i ? '  — ' + i : ''));
async function setup(p) {
  await p.route(/fonts\.googleapis|jsdelivr/, r => r.abort());
  await p.route('https://ypu.test/config.js', r => r.fulfill({ contentType: 'text/javascript', body: "window.YPU_API='https://script.google.com/macros/s/X/exec';" }));
  await p.route(/https:\/\/ypu\.test\/(\?.*)?$/, r => r.fulfill({ contentType: 'text/html', body: html }));
  await p.route('https://script.google.com/**', async r => { const body = r.request().postData(); await sleep(1200); fresh(); r.fulfill({ contentType: 'application/json', body: ctx.doPost({ postData: { contents: body } }) }); });
}
// クリックしてから、条件が画面で満たされるまでの時間（4倍遅いCPU）
async function timed(p, clickFn, condFn) {
  return p.evaluate(async ([c, d]) => {
    const t0 = performance.now(); (new Function(c))();
    const cond = new Function(d);
    return new Promise(res => { const tick = () => { if (cond()) { requestAnimationFrame(() => res(Math.round(performance.now() - t0))); } else if (performance.now() - t0 > 5000) res(9999); else requestAnimationFrame(tick); }; tick(); });
  }, [clickFn, condFn]);
}
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const [tag, opt] of [['PC', { viewport: { width: 1400, height: 900 } }], ['スマホ', devices['iPhone 13']]]) {
    const c = await b.newContext(opt); const p = await c.newPage(); p.on('pageerror', e => errs.push(tag + ': ' + e.message));
    const cdp = await c.newCDPSession(p); await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    await setup(p);
    await p.goto('https://ypu.test/'); await p.evaluate(() => localStorage.setItem('ypu_token', 'tok')); await p.goto('https://ypu.test/');
    await p.waitForSelector('[data-act="openPj"]'); await p.click('[data-act="openPj"]'); await p.waitForSelector('.tile'); await sleep(3000);
    await p.click('[data-act="page"][data-v="メンバー表"]'); await sleep(1500);
    // 受付ボタン
    await p.evaluate(() => { window.__was = document.querySelector('[data-act="recv"]').textContent; });
    let ms = await timed(p, `document.querySelector('[data-act="recv"]').click()`, `return document.querySelector('[data-act="recv"]').textContent !== window.__was`);
    ok(tag + '：受付 → 受付済 に変わるまで', ms < 100, ms + 'ms');
    await sleep(2000);
    // 当日参加を追加（300人いて一覧の後ろに入る）
    await p.fill('#gName', '新しい人A');
    ms = await timed(p, `document.querySelector('form[data-form="guestAdd"] button').click()`, `return [...document.querySelectorAll('input[data-f="name"], .card b')].some(x => (x.value || x.textContent) === '新しい人A')`);
    ok(tag + '：当日参加を追加 → 一覧に出るまで（300人の後ろ）', ms < 200, ms + 'ms');
    const vis = await p.evaluate(() => { const el = [...document.querySelectorAll('input[data-f="name"], .card b')].find(x => (x.value || x.textContent) === '新しい人A'); const r = el.getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight; });
    ok(tag + '：追加した人が画面内に見えている', vis);
    ok(tag + '：氏名欄にカーソルが戻る（続けて入力できる）', tag === 'スマホ' || await p.evaluate(() => document.activeElement && document.activeElement.id === 'gName'));
    await sleep(2500);
    ok(tag + '：追加した人が保存された', rows('当日参加者').some(r => r['氏名'] === '新しい人A'));
    if (tag === 'PC') {
      // ToDo：＋行を追加 → すぐ入力 → 保存の途中でIDが変わっても入力が続く
      await p.click('[data-act="go"][data-v="home"]'); await p.click('[data-act="page"][data-v="ToDo"]'); await sleep(1500);
      ms = await timed(p, `document.querySelectorAll('[data-act="addRow"]')[2].click()`, `return !!document.querySelector('input[data-f="sub"][data-id^="tmp"]')`);
      ok('PC：＋行を追加 → 行が出るまで（200行の後ろのグループ）', ms < 200, ms + 'ms');
      await sleep(80);
      ok('PC：新しい行の小見出しにカーソル', await p.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-f') === 'sub' && /^tmp/.test(document.activeElement.getAttribute('data-id'))));
      await sleep(1600); // 保存が終わってIDが決まる
      ok('PC：IDが決まってもカーソルはそのまま', await p.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-f') === 'sub' && /^T\d+/.test(document.activeElement.getAttribute('data-id'))));
      await p.keyboard.type('すぐ入力'); await p.keyboard.press('Tab'); await sleep(2800);
      ok('PC：その行に入力した内容も保存', rows('ToDo').some(r => r['小見出し'] === 'すぐ入力'));
    }
    await c.close();
  }
  // 受付リンク（スマホ・ログインなし）
  const share = ctx.shareCreate('tok', 'PJ001', 3); const key = share.parts.share.key;
  const gc = await b.newContext(devices['iPhone 13']); const gp = await gc.newPage(); gp.on('pageerror', e => errs.push('受付リンク: ' + e.message));
  const cdp2 = await gc.newCDPSession(gp); await cdp2.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  await setup(gp); await gp.goto('https://ypu.test/?guest=' + key); await gp.waitForSelector('.sw[data-sk="glink"]'); await sleep(500);
  let ms = await timed(gp, `document.querySelectorAll('[data-act="recv"]')[3].click()`, `const b = document.querySelectorAll('[data-act="recv"]')[3]; return b.classList.contains('on') !== (b.dataset.was === '1')`);
  await gp.evaluate(() => { const b = document.querySelectorAll('[data-act="recv"]')[3]; b.dataset.was = b.classList.contains('on') ? '1' : '0'; });
  ms = await timed(gp, `document.querySelectorAll('[data-act="recv"]')[4].click()`, `return document.querySelectorAll('[data-act="recv"]')[4].classList.contains('on')`);
  ok('受付リンク：受付ボタンが変わるまで', ms < 100, ms + 'ms');
  await gp.fill('#gnName', '飛び入りB');
  ms = await timed(gp, `document.querySelector('form[data-form="guestNew"] button').click()`, `return [...document.querySelectorAll('.card b')].some(x => x.textContent === '飛び入りB')`);
  ok('受付リンク：飛び入りを追加 → 一覧に出るまで（300人の後ろ）', ms < 300, ms + 'ms');
  await sleep(3000);
  ok('受付リンク：保存後も一覧に出たまま', await gp.evaluate(() => [...document.querySelectorAll('.card b')].some(x => x.textContent === '飛び入りB')));
  console.log(results.join('\n')); console.log(errs.length ? 'エラー: ' + errs.join(' / ') : 'ページのエラー: なし');
  process.exitCode = (results.some(r => r.startsWith('❌')) || errs.length) ? 1 : 0;
  await b.close();
})().catch(e => { console.log(results.join('\n')); console.error('止まった:', e.message); process.exit(1); });
