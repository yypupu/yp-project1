// 見た目の確認用スクリーンショット（テストではない）: node tools/test/shots.js
const path = require('path'), fs = require('fs'), vm = require('vm');
const M = require('./gasmock.js'); const { ctx, sheets, props } = M;
const { chromium } = require('playwright');
const OUT = path.join(__dirname, 'out'); fs.mkdirSync(OUT, { recursive: true });
const html = fs.readFileSync(path.join(M.REPO, 'index.html'), 'utf8');
const add = (name, n, mk) => { const d = sheets[name]._data(); const head = d[0]; for (let i = 0; i < n; i++) { const o = mk(i); d.push(head.map(h => (h in o) ? o[h] : '')); } };
const iso = n => { const d = new Date(Date.now() + n * 864e5); return d.toISOString().slice(0, 10); };
add('ToDo', 24, i => ({ 'ID': 'T' + String(100 + i).padStart(4, '0'), 'PJ ID': 'PJ001', '大見出し': ['全体・制作：会場', '広報：チラシ', 'ステージ：出演者', 'ブース：縁日'][i % 4], 'ステータス': ['未着手', '進行中', '完了'][i % 3], '小見出し': 'タスク' + i, '締切日': iso(i % 9 - 3), '担当者': i % 2 ? '田中' : '鈴木' }));
props.set('s:tok', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 1e9 }));
const fresh = () => vm.runInContext('for (const k in MEMO_) delete MEMO_[k]; SS_ = null; TZ_CACHE = "";', ctx);
async function setup(page) {
  await page.route(/fonts\.googleapis|jsdelivr/, r => r.abort());
  await page.route('https://ypu.test/config.js', r => r.fulfill({ contentType: 'text/javascript', body: "window.YPU_API='https://script.google.com/macros/s/X/exec';" }));
  await page.route('https://ypu.test/', r => r.fulfill({ contentType: 'text/html', body: html }));
  await page.route('https://script.google.com/**', async r => { fresh(); r.fulfill({ contentType: 'application/json', body: ctx.doPost({ postData: { contents: r.request().postData() } }) }); });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const b = await chromium.launch();
  for (const [nm, vp] of [['pc', { width: 1400, height: 900 }], ['sp', { width: 390, height: 844 }]]) {
    const p = await b.newPage({ viewport: vp }); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await setup(p); await p.goto('https://ypu.test/'); await p.evaluate(() => localStorage.setItem('ypu_token', 'tok')); await p.goto('https://ypu.test/');
    await p.waitForSelector('[data-act="openPj"]'); await p.click('[data-act="openPj"]'); await sleep(700);
    await p.screenshot({ path: OUT + '/' + nm + '_home.png', fullPage: true });
    for (const pg of ['ToDo', '集客アタック', 'メンバー表', '備品表', '制作物・図面']) {
      await p.click('[data-act="drawer"]'); await sleep(150);
      if (pg === 'ToDo') await p.screenshot({ path: OUT + '/' + nm + '_drawer.png' });
      await p.click('.drawer .navgo:has-text("' + pg + '")'); await sleep(500);
      if (pg === 'ToDo') await p.click('[data-act="todoStatus"][data-v="すべて"]');
      await sleep(200); await p.screenshot({ path: OUT + '/' + nm + '_' + pg.replace(/[・]/g, '') + '.png', fullPage: nm === 'pc' ? false : true });
    }
    await p.click('[data-act="bell"]'); await sleep(150); await p.screenshot({ path: OUT + '/' + nm + '_bell.png' }); await p.keyboard.press('Escape');
    await p.click('[data-act="drawer"]'); await p.click('.drawer .navgo:has-text("集客アタック")'); await sleep(300);
    if (nm === 'pc') { await p.click('table[data-tbl="atk"] .colplus'); await sleep(150); await p.screenshot({ path: OUT + '/pc_colmgr.png' }); await p.keyboard.press('Escape'); await p.click('[data-act="kindEdit"]'); await sleep(150); await p.screenshot({ path: OUT + '/pc_kinds.png' }); }
    console.log(nm, 'errors:', errs.join(' | ') || 'なし');
  }
  await b.close();
})();
