// Google Apps Script のまねをして、サーバーのコードを手元で動かすための道具
const fs = require('fs');
const vm = require('vm');
const path = require('path');
// 調べるサーバーのコードと、まねのスプレッドシートの中身（変えたいときは環境変数で）
const REPO = path.resolve(__dirname, '..', '..');
const CODE = process.env.GAS_CODE || path.join(REPO, 'gas', 'コード.gs');
const DATA = process.env.TEST_DATA || path.join(__dirname, 'test-data.json');
const XLSX_SHEETS = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const STATS = { open: 0, read: 0, write: 0, del: 0, cacheGet: 0, propGet: 0 };

function makeSheet(name, rows) {
  let data = rows.map(r => r.slice());
  const width = () => Math.max(1, ...data.map(r => r.length));
  const pad = () => { const w = width(); data.forEach(r => { while (r.length < w) r.push(''); }); };
  pad();
  const lastRow = () => { let n = data.length; while (n > 0 && data[n - 1].every(c => c === '' || c === null)) n--; return n; };
  const sh = {
    getName: () => name,
    getLastRow: lastRow,
    getLastColumn: () => width(),
    getDataRange: () => ({ getValues: () => { STATS.read++; return data.slice(0, Math.max(1, lastRow())).map(r => r.slice()); }, getDisplayValues: () => data.slice(0, lastRow()).map(r => r.map(String)) }),
    getRange: (r, c, nr = 1, nc = 1) => ({
      getValues: () => { STATS.read++; return Array.from({ length: nr }, (_, i) => Array.from({ length: nc }, (_, j) => (data[r - 1 + i] || [])[c - 1 + j] ?? '')); },
      setValues: (vals) => {
        STATS.write++; let bad = null;
        vals.forEach((row, i) => { while (data.length < r + i) data.push(Array(width()).fill('')); row.forEach((v, j) => {
          const rule = sh._rules[c - 1 + j];   // まねの入力規則（その列は list の値か空だけ）
          if (rule && r + i > 1 && v !== '' && !rule.includes(String(v))) { bad = bad || (r + i) + '行' + (c + j) + '列'; return; }
          data[r - 1 + i][c - 1 + j] = (typeof v === 'string' && v.startsWith("'")) ? v.slice(1) : v; }); });
        pad();
        if (bad) throw new Error('選択肢から選んでください - 候補にない値です（' + bad + '）');
        return sh.getRange(r, c, nr, nc);
      },
      getDataValidations: () => Array.from({ length: nr }, () => Array.from({ length: nc }, (_, j) => { const rule = sh._rules[c - 1 + j]; return rule ? { getAllowInvalid: () => false, getCriteriaType: () => 'VALUE_IN_LIST', getCriteriaValues: () => [rule] } : null; })),
      setFontWeight() { return this; }, setBackground() { return this; }
    }),
    deleteRow: (r) => { STATS.del++; data.splice(r - 1, 1); },
    deleteRows: (r, n) => { STATS.del++; data.splice(r - 1, n); },
    appendRow: (row) => { STATS.write++; data.splice(lastRow(), 0, row); pad(); },
    setFrozenRows() {}, getSheetId: () => 1, _rules: {},
    _data: () => data
  };
  return sh;
}
const sheets = {};
Object.keys(XLSX_SHEETS).forEach(n => { sheets[n] = makeSheet(n, XLSX_SHEETS[n]); });
const SS = { getId: () => 'SSID', getSheetByName: n => sheets[n] || null, getSheets: () => Object.values(sheets), insertSheet: n => (sheets[n] = makeSheet(n, [[]])), getSpreadsheetTimeZone: () => 'Asia/Tokyo' };
const cacheStore = new Map(), props = new Map([['SS_ID', 'SSID']]);
const pad2 = n => String(n).padStart(2, '0');
function fmt(d, tz, f) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(d).map(x => [x.type, x.value]));
  return f.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute).replace('ss', p.second);
}
const ctx = {
  console, JSON, Math, Date, String, Number, Object, Array, Error, RegExp, Intl,
  SpreadsheetApp: { DataValidationCriteria: { CHECKBOX: 'CHECKBOX', VALUE_IN_LIST: 'VALUE_IN_LIST', VALUE_IN_RANGE: 'VALUE_IN_RANGE' }, openById: () => { STATS.open++; return SS; }, getActive: () => SS, getActiveSpreadsheet: () => SS, getUi: () => ({ alert: m => console.log('ALERT', m), createMenu: () => ({ addItem() { return this; }, addToUi() {} }) }), openByUrl: () => { throw new Error('no'); } },
  CacheService: { getScriptCache: () => ({ get: k => { STATS.cacheGet++; return cacheStore.get(k) ?? null; }, getAll: ks => { STATS.cacheGet++; const o = {}; ks.forEach(k => { if (cacheStore.has(k)) o[k] = cacheStore.get(k); }); return o; }, put: (k, v) => cacheStore.set(k, v), remove: k => cacheStore.delete(k), removeAll: ks => ks.forEach(k => cacheStore.delete(k)) }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: k => { STATS.propGet++; return props.get(k) ?? null; }, setProperty: (k, v) => props.set(k, v), deleteProperty: k => props.delete(k), getProperties: () => Object.fromEntries(props) }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  Session: { getScriptTimeZone: () => 'Asia/Tokyo' },
  Utilities: { formatDate: fmt, parseDate: (s, tz, f) => new Date(s + 'T00:00:00+09:00'), getUuid: () => require('crypto').randomUUID() },
  MailApp: { getRemainingDailyQuota: () => 100, sendEmail: () => {} },
  ScriptApp: { getProjectTriggers: () => [], getService: () => ({ getUrl: () => '' }) },
  HtmlService: {}, ContentService: { createTextOutput: s => ({ setMimeType: () => s }), MimeType: {} },
  FormApp: { getActiveForm: () => null }, UrlFetchApp: {}, Logger: { log() {} }
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(CODE, 'utf8') + '\n;this.__x = { API: typeof API !== "undefined" ? API : null };', ctx);
module.exports = { REPO, ctx, STATS, sheets, props, cacheStore, reset: () => Object.keys(STATS).forEach(k => STATS[k] = 0) };
