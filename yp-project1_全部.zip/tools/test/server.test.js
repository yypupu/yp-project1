// サーバー（gas/コード.gs）の大事な動きを、まねのスプレッドシートで確かめる
// 使い方: node tools/test/server.test.js
const vm = require('vm');
const M = require('./gasmock.js');
const { ctx, sheets, props, cacheStore } = M;
const results = [];
const ok = (name, cond, info) => results.push((cond ? '✅ ' : '❌ ') + name + (info ? '  — ' + info : ''));
const run = (code) => vm.runInContext(code, ctx);
// GASは呼び出しごとにまっさらから始まるので、毎回メモを消す
const fresh = () => { try { run('for (const k in MEMO_) delete MEMO_[k]; SS_ = null; TZ_CACHE = "";'); } catch (e) { } };
const callApi = (fn, ...args) => { fresh(); M.reset(); return { r: ctx[fn](...args), s: { ...M.STATS } }; };
const rowsOf = (name) => { const d = sheets[name]._data(); const h = d[0]; return d.slice(1).filter(r => r.some(c => c !== '')).map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };

props.set('s:tok', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 1e9 }));
const ALL = ['todo', 'atk', 'guest', 'staff', 'share', 'equip', 'work', 'doc', 'ttcfg', 'block', 'flow'];

try {
  // 読み込み
  let a = callApi('getProject', 'tok', 'PJ001', ALL);
  ok('全ページ分を1回で読める', !!a.r.parts && ALL.every(k => k in a.r.parts));
  ok('スプレッドシートを開くのは1回だけ', a.s.open <= 1, '開いた回数 ' + a.s.open);
  ok('画面とサーバーの版を返す', typeof a.r.sv === 'string' && a.r.sv.length > 0, a.r.sv);
  // 30秒ごとの確認
  const v = a.r.ver;
  let s1 = callApi('sync', 'tok', 'PJ001', ['todo'], v);
  ok('変化がないときは same を返す', s1.r.same === true);
  ok('変化がないときはシートを読まない', s1.s.read <= 3, '読んだ回数 ' + s1.s.read);
  // 保存
  const id = a.r.parts.todo[0].id;
  let b = callApi('saveRows', 'tok', 'PJ001', 'todo', [{ id, status: '完了' }]);
  ok('1か所を保存できる', b.r.rows.find(x => x.id === id).status === '完了');
  ok('保存すると版が変わる', b.r.ver !== v);
  ok('古い版で確認すると same にならない', !callApi('sync', 'tok', 'PJ001', ['todo'], v).r.same);
  // まとめて追加・日付の書き方
  const n0 = rowsOf('ToDo').length;
  let c = callApi('saveRows', 'tok', 'PJ001', 'todo', [{ group: 'テスト', sub: 'A', end: '11/3' }, { group: 'テスト', sub: 'B', end: '2026/11/4' }, { group: 'テスト', sub: 'C', end: '2026-11-05' }]);
  ok('まとめて追加（1回の通信）', c.r.ids.length === 3 && rowsOf('ToDo').length === n0 + 3);
  ok('いろいろな日付の書き方を読める', /^\d{4}-11-03$/.test(c.r.rows.find(x => x.id === c.r.ids[0]).end) && c.r.rows.find(x => x.id === c.r.ids[1]).end === '2026-11-04');
  ok('ToDoのステータスにない値は入れない', (() => { const x = callApi('saveRows', 'tok', 'PJ001', 'todo', [{ id: c.r.ids[0], status: 'へんな値' }]); return x.r.rows.find(r => r.id === c.r.ids[0]).status !== 'へんな値'; })());
  // まとめて削除
  let d = callApi('deleteRows', 'tok', 'PJ001', 'todo', c.r.ids);
  ok('まとめて削除', rowsOf('ToDo').length === n0 && !d.r.rows.some(x => c.r.ids.includes(x.id)));
  ok('変更ログに記録される', rowsOf('変更ログ').length >= 6);
  // 権限
  let denied = false; try { callApi('getProject', 'bad-token', 'PJ001', ['todo']); } catch (e) { denied = /LOGIN/.test(e.message); }
  ok('ログインしていないと読めない', denied);
  // アタックの重複チェック
  const atkName = a.r.parts.atk[0] && a.r.parts.atk[0].name;
  if (atkName) ok('アタック先の重複を知らせる', !!callApi('saveRows', 'tok', 'PJ001', 'atk', [{ name: atkName, kind: '学生' }]).r.dup);
  // ログインコードの送信上限（1時間に3回）
  let mails = 0; ctx.MailApp.sendEmail = () => { mails++; };
  const email = 'tanaka@y-pu.example';
  const send = () => { cacheStore.delete('wait:' + email); return ctx.requestCode(email); };
  const r4 = [send(), send(), send(), send()];
  ok('ログインコードは1時間に3回まで', r4.slice(0, 3).every(x => x.ok) && !r4[3].ok && mails === 3, '送った ' + mails + '通');
  ok('登録されていないアドレスには送らない', !ctx.requestCode('nobody@example.com').ok);
  // 手でシートを直したとき（onEdit）
  const v2 = callApi('sync', 'tok', 'PJ001', ['todo'], '').r.ver;
  ctx.onEdit({ range: { getSheet: () => ({ getName: () => 'ユーザー' }) } });
  ok('シートを手で直すと画面に知らせる', !callApi('sync', 'tok', 'PJ001', ['todo'], v2).r.same);

  // 備品：シートの入力規則に合わない値があっても、エラーにせず保存して知らせる
  const eqSh = sheets['備品'], eqHead = eqSh._data()[0];
  eqSh._rules[eqHead.indexOf('搬入')] = ['TRUE', 'FALSE'];
  eqSh._rules[eqHead.indexOf('区分')] = ['レンタル', '購入'];   // 会社在庫が入っていない（よくある設定のずれ）
  const eqN = rowsOf('備品').length;
  let eq = callApi('saveRows', 'tok', 'PJ001', 'equip', [{ name: 'テント', qty: 2 }, { name: 'イス', qty: 6 }]);
  ok('備品：入力規則に合わない値があっても追加できる', eq.r.ids.length === 2 && rowsOf('備品').length === eqN + 2);
  ok('備品：何を空にしたかを知らせる', /区分/.test(eq.r.warn || ''), eq.r.warn);
  ok('備品：ほかの値はちゃんと入る', eq.r.rows.find(x => x.id === eq.r.ids[1]).qty === 6);
  eqSh._rules = {};
  callApi('deleteRows', 'tok', 'PJ001', 'equip', eq.r.ids);

  // 新しい列（電話番号など）は、シートになくても自動で足される
  const atkSh = sheets['アタック'];
  const hadTel = atkSh._data()[0].includes('電話番号');
  let t1 = callApi('saveRows', 'tok', 'PJ001', 'atk', [{ name: 'テスト社', kind: '企業', tel: '06-0000-0000' }], true);
  ok('足りない列（電話番号）を自動で足す', atkSh._data()[0].includes('電話番号') && t1.r.rows.find(x => x.id === t1.r.ids[0]).tel === '06-0000-0000', hadTel ? '最初からあった' : '');
  // 自分たちで足した列の値（追加項目）
  const aid = t1.r.ids[0];
  callApi('saveRows', 'tok', 'PJ001', 'atk', [{ id: aid, ext: { c1: 'あいう' } }]);
  let t2 = callApi('saveRows', 'tok', 'PJ001', 'atk', [{ id: aid, ext: { c2: '123' } }]);
  const ex = t2.r.rows.find(x => x.id === aid).ext;
  ok('追加項目：別々に保存しても両方残る', ex.c1 === 'あいう' && ex.c2 === '123', JSON.stringify(ex));
  let t3 = callApi('saveRows', 'tok', 'PJ001', 'atk', [{ id: aid, ext: { c1: '' } }]);
  ok('追加項目：空にすると消える', !('c1' in t3.r.rows.find(x => x.id === aid).ext));
  callApi('deleteRows', 'tok', 'PJ001', 'atk', [aid]);

  // 表の列の設定（プロジェクトごと）
  let cc = callApi('saveColCfg', 'tok', 'PJ001', 'atk:企業', { order: ['name', 'status', 'x:c1'], hide: ['est'], custom: [{ id: 'c1', label: '電話番号2', type: 'text' }, { id: '<>', label: 'x' }] });
  ok('列の設定を保存できる', cc.r.cfg.custom.length === 1 && cc.r.cfg.custom[0].label === '電話番号2');
  ok('列の設定が読み込みで返る', callApi('getProject', 'tok', 'PJ001', ['atk']).r.cols['atk:企業'].hide[0] === 'est');
  ok('列の設定はほかのプロジェクトに出ない', (fresh(), !ctx.colCfgs_('PJ999')['atk:企業']));

  // 選択肢の編集（名前を変えると入っている値も変わる）
  const a0 = callApi('getProject', 'tok', 'PJ001', ['atk']).r;
  const stOld = a0.choices['アタックステータス'];
  const someAtk = a0.parts.atk.find(x => x.status === '連絡済');
  let ch = callApi('saveChoices', 'tok', 'PJ001', 'アタックステータス', stOld.map(x => x === '連絡済' ? '連絡した' : x).concat(['保留']), { '連絡済': '連絡した' });
  ok('選択肢を編集できる', ch.r.choices['アタックステータス'].includes('保留') && ch.r.choices['アタックステータス'].includes('連絡した'));
  if (someAtk) ok('選択肢の名前を変えると、入っている値も変わる', callApi('getProject', 'tok', 'PJ001', ['atk']).r.parts.atk.find(x => x.id === someAtk.id).status === '連絡した');
  callApi('saveChoices', 'tok', 'PJ001', 'アタックステータス', stOld, { '連絡した': '連絡済' });
  ok('アタックの種類も選択肢にある', (a0.choices['アタック種類'] || []).includes('企業'));

  // ログインの期限は使うたびに延びる
  props.set('s:old', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 5 * 86400000 }));
  callApi('getProject', 'old', 'PJ001', ['todo']);
  ok('ログインの期限が使うたびに延びる', JSON.parse(props.get('s:old')).exp > Date.now() + 80 * 86400000);
  ok('アンケートの応答にも版がつく', (() => { try { return callApi('getForms', 'tok', 'PJ001').r.sv === ctx.APP_VERSION || !!callApi('getForms', 'tok', 'PJ001').r.sv; } catch (e) { return false; } })());
} catch (e) {
  results.push('❌ 途中で止まった：' + e.message);
}
console.log(results.join('\n'));
process.exitCode = results.some(r => r.startsWith('❌')) ? 1 : 0;
