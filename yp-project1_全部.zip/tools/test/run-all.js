// すべてのテストを順番に動かす。1つでも ❌ があれば終了コード1
// 使い方（リポジトリの一番上で）: node tools/test/run-all.js
// 画面のテストには Playwright が必要: cd tools/test && npm install && npx playwright install chromium
const { spawnSync } = require('child_process');
const path = require('path');
const tests = ['server.test.js', 'ui-main.test.js', 'ui-pages.test.js', 'ui-longlist.test.js', 'ui-speed.test.js'];
const only = process.argv.slice(2);
let failed = 0;
for (const t of tests) {
  if (only.length && !only.some(o => t.includes(o))) continue;
  console.log('\n===== ' + t + ' =====');
  const r = spawnSync(process.execPath, [path.join(__dirname, t)], { stdio: 'inherit', timeout: 600000 });
  if (r.status !== 0) { failed++; console.log('→ ' + t + ' に失敗があります'); }
}
console.log(failed ? '\n❌ 失敗したテスト：' + failed + '個' : '\n✅ すべてのテストが通りました');
process.exitCode = failed ? 1 : 0;
