// 残りのページ（タイムテーブル・備品・制作物・資料・メンバー・受付リンク・分析・設定）を本物のサーバーコードで一通り動かす
const path = require('path'), fs = require('fs'), vm = require('vm');
const M = require('./gasmock.js');
const { ctx, sheets, props } = M;
const { chromium, devices } = require('playwright');
const OUT = path.join(__dirname, 'out'); fs.mkdirSync(OUT, { recursive: true });
const LAT = 500;
const html = fs.readFileSync(path.join(M.REPO, 'index.html'), 'utf8');
props.set('s:tok', JSON.stringify({ email: 'tanaka@y-pu.example', exp: Date.now() + 1e9 }));
const fresh = () => vm.runInContext('for (const k in MEMO_) delete MEMO_[k]; SS_ = null; TZ_CACHE = "";', ctx);
const rows = name => { const d = sheets[name]._data(); const h = d[0]; return d.slice(1).filter(r => r.some(c => c !== '')).map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };
const results = []; const ok = (n, c, i) => results.push((c ? '✅ ' : '❌ ') + n + (i ? '  — ' + i : ''));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const idle = async (p) => { await sleep(60); for (let i = 0; i < 80; i++) { if (!(await p.evaluate(() => !!document.querySelector('#st .spin') || document.getElementById('netbar').classList.contains('on')))) return; await sleep(150); } };
async function setup(page, url) {
  await page.route(/fonts\.googleapis|jsdelivr/, r => r.abort());
  await page.route('https://ypu.test/config.js', r => r.fulfill({ contentType: 'text/javascript', body: "window.YPU_API='https://script.google.com/macros/s/X/exec';" }));
  await page.route(/https:\/\/ypu\.test\/(\?.*)?$/, r => r.fulfill({ contentType: 'text/html', body: html }));
  await page.route('https://script.google.com/**', async r => { const body = r.request().postData(); await sleep(LAT); fresh(); r.fulfill({ contentType: 'application/json', body: ctx.doPost({ postData: { contents: body } }) }); });
}
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const [tag, opt] of [['pc', { viewport: { width: 1400, height: 900 } }], ['sp', devices['iPhone 13']]]) {
    const c = await b.newContext(opt); const p = await c.newPage();
    p.on('pageerror', e => errs.push(tag + ': ' + e.message));
    await setup(p);
    await p.goto('https://ypu.test/'); await p.evaluate(() => localStorage.setItem('ypu_token', 'tok')); await p.goto('https://ypu.test/');
    await p.waitForSelector('[data-act="openPj"]'); await p.click('[data-act="openPj"]'); await p.waitForSelector('.tile'); await idle(p);
    await p.addStyleTag({ content: '.top{position:static}' });
    const go = async (v) => { if (await p.$('[data-act="go"][data-v="home"]')) await p.click('[data-act="go"][data-v="home"]'); await p.click(`[data-act="page"][data-v="${v}"]`); await idle(p); };
    for (const v of ['備品表', '制作物・図面', '資料', 'メンバー表', 'タイムテーブル', 'アンケート分析', '権限・連携']) {
      await go(v); await p.screenshot({ path: `${OUT}/${tag}2_${v}.png`, fullPage: true });
      ok(`${tag}：${v} が開く`, !(await p.$('.skel')), '');
    }
    if (tag === 'pc') {
      // 備品：追加 → 品名入力 → 当日チェック
      await go('備品表');
      const e0 = rows('備品').length;
      await p.click('[data-act="addEquip"]'); const nm = 'input[data-t="equip"][data-f="name"][data-id^="tmp"]'; await p.fill(nm, 'マイク'); await p.keyboard.press('Tab'); await idle(p);
      ok('備品：追加して品名を保存', rows('備品').length === e0 + 1 && rows('備品').some(r => r['品名'] === 'マイク'));
      await p.click('[data-act="equipMode"][data-v="day"]');
      const id = rows('備品').find(r => r['品名'] === 'マイク').ID;
      await p.click(`[data-act="eqCheck"][data-k="inC"][data-v="${id}"]`); await idle(p);
      ok('備品：搬入チェックが保存', String(rows('備品').find(r => r.ID === id)['搬入']).toUpperCase() === 'TRUE');
      // 資料：追加 → URL
      await go('資料'); const d0 = rows('資料').length;
      await p.click('[data-act="addDoc"]'); await p.fill('input[data-t="doc"][data-f="url"][data-id^="tmp"]', 'https://drive.google.com/x'); await p.keyboard.press('Tab'); await idle(p);
      ok('資料：追加してリンクを保存', rows('資料').length === d0 + 1 && rows('資料').some(r => r['URL'] === 'https://drive.google.com/x'));
      // タイムテーブル：枠を追加 → 文字と色
      await go('タイムテーブル'); const b0 = rows('タイテ枠').length;
      await p.click('[data-act="addBlock"]'); await sleep(50);
      ok('タイテ：枠がすぐプレビューに出る', !!(await p.$('[data-blk^="tmp"]')));
      await p.fill('textarea[data-t="block"][data-id^="tmp"]', '受付\nスタート'); await p.keyboard.press('Tab'); await idle(p);
      const nb = rows('タイテ枠').find(r => String(r['文字']).includes('受付'));
      ok('タイテ：枠の文字が保存', rows('タイテ枠').length === b0 + 1 && !!nb, nb && JSON.stringify(nb['文字']));
      await p.selectOption(`select[data-t="block"][data-f="st"][data-id="${nb.ID}"]`, 'ブルー'); await idle(p);
      ok('タイテ：色の変更が保存', rows('タイテ枠').find(r => r.ID === nb.ID)['色'] === 'ブルー');
      ok('タイテ：保存後もその枠が選ばれたまま', !!(await p.$(`.blk.sel#blk-${nb.ID}`)));
      await p.fill('input[data-col="0"][data-cf="w"]', '160'); await p.click('[data-act="ttSave"]'); await idle(p);
      ok('タイテ：列の幅を保存', rows('タイテ列').some(r => Number(r['幅']) === 160));
      await p.click('[data-act="ttTab"][data-v="flow"]'); const f0 = rows('簡易タイテ').length;
      await p.click('[data-act="addFlow"]'); await p.fill('input[data-t="flow"][data-f="item"][data-id^="tmp"]', '開場'); await p.keyboard.press('Tab'); await idle(p);
      ok('簡易タイテ：行を追加', rows('簡易タイテ').length === f0 + 1 && rows('簡易タイテ').some(r => r['内容'] === '開場'));
      await p.screenshot({ path: `${OUT}/pc2_flow.png`, fullPage: true });
      // メンバー：受付リンク発行 → ログインなしで開く
      await go('メンバー表'); if (await p.$('[data-act="shareStop"]')) { await p.click('[data-act="shareStop"]'); await idle(p); ok('受付リンクを止める', !!(await p.$('[data-act="shareCreate"]'))); } await p.click('[data-act="shareCreate"]'); await idle(p);
      const link = await p.inputValue('#shareLink');
      ok('受付リンクを発行', /\?guest=[0-9a-f]{24}$/.test(link), link);
      const key = link.split('guest=')[1];
      const gc = await b.newContext(devices['iPhone 13']); const gp = await gc.newPage(); gp.on('pageerror', e => errs.push('guest: ' + e.message));
      await setup(gp); await gp.goto('https://ypu.test/?guest=' + key); await gp.waitForSelector('.sw[data-sk="glink"]');
      const gid = await gp.getAttribute('.sw[data-sk="glink"]', 'data-sid');
      const was = rows('当日参加者').find(r => r.ID === gid)['受付'] === '済';
      await gp.tap(`[data-act="recv"][data-v="${gid}"]`); await sleep(30);
      const txt = await gp.textContent(`[data-act="recv"][data-v="${gid}"]`);
      ok('受付リンク：押した瞬間に切り替わる', was ? txt.trim() === '受付' : /受付済/.test(txt), (was ? '受付済→' : '未→') + txt.trim());
      await idle(gp); await sleep(LAT);
      ok('受付リンク：保存される', (rows('当日参加者').find(r => r.ID === gid)['受付'] === '済') === !was);
      await gp.tap(`[data-act="recv"][data-v="${gid}"]`); await sleep(LAT * 2 + 200);
      ok('受付リンク：もう一度押すと元に戻る', (rows('当日参加者').find(r => r.ID === gid)['受付'] === '済') === was);
      await gp.fill('#gnName', '飛び入り 太郎'); await gp.tap('form[data-form="guestNew"] button'); await sleep(30);
      ok('受付リンク：当日参加者をすぐ追加', (await gp.textContent('main')).includes('飛び入り 太郎'));
      await sleep(LAT * 2 + 200);
      ok('受付リンク：当日参加者が保存される', rows('当日参加者').some(r => r['氏名'] === '飛び入り 太郎' && r['追加元'] === '当日追加'));
      await gp.screenshot({ path: `${OUT}/guest_link.png`, fullPage: true });
      // 設定：ユーザー名を変える
      await go('権限・連携'); await p.fill('tr[data-urow="suzuki@example.com"] input[data-u="first"]', '花'); await p.keyboard.press('Tab'); await idle(p);
      ok('設定：ユーザーの変更が保存', rows('ユーザー').find(r => r['メールアドレス'] === 'suzuki@example.com')['名前'] === '花');
    }
    await c.close();
  }
  console.log(results.join('\n'));
  console.log(errs.length ? 'ページのエラー:\n' + errs.join('\n') : 'ページのエラー: なし');
  process.exitCode = (results.some(r => r.startsWith('❌')) || errs.length) ? 1 : 0;
  await b.close();
})().catch(e => { console.log(results.join('\n')); console.error('止まった:', e.message); process.exit(1); });
