# gas/Index.html（Apps Script用の画面）から、GitHub Pages 用の index.html を作る
# 使い方（リポジトリの一番上で）: python3 tools/build_hosted.py
# 画面を直すときは gas/Index.html だけを直し、このスクリプトで index.html を作り直すこと（index.html を直接直さない）
import os, sys

repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(repo, 'gas', 'Index.html')
dst = sys.argv[2] if len(sys.argv) > 2 else os.path.join(repo, 'index.html')
s = open(src, encoding='utf-8').read()

def swap(old, new):
    global s
    if old not in s:
        sys.exit('gas/Index.html の中に、置き換える場所が見つかりません：' + old[:60])
    s = s.replace(old, new, 1)

s = s.replace('<!-- Apps Script から開いたときは、ここにサイトのURLと受付リンクの合言葉が自動で入ります -->\n', '')
swap('<div id="cfg" data-api="<?= apiUrl ?>" data-guest="<?= guestKey ?>" hidden></div>', '<div id="cfg" hidden></div>')
swap("var API_URL_HOSTED = '';", "var API_URL_HOSTED = window.YPU_API || '';")
swap('<base target="_top">', '<base target="_top">\n<title>Y-PU プロジェクト</title>\n<script src="config.js"></script>')
swap("'<p style=\"font-size:14px;line-height:1.8\">これはApps Scriptに貼るためのファイルです。",
     "'<p style=\"font-size:14px;line-height:1.8\">config.js にウェブアプリのURLが入っていないか、config.js が見つかりません。config.js の \\'\\' の中に https://script.google.com/macros/s/…/exec を貼ってください。</p><p style=\"font-size:14px;line-height:1.8\">これはApps Scriptに貼るためのファイルです。")
if '<?' in s:
    sys.exit('index.html に Apps Script 用の <? ?> が残っています')
open(dst, 'w', encoding='utf-8').write(s)
print('作りました:', os.path.relpath(dst, repo))
