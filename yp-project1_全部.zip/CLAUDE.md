# CLAUDE.md — このリポジトリで作業する Claude へ

Y-PU ENTERTAINMENT の学生プロジェクト運営アプリ。使う人は大学生のインターン・メンバーと社員で、**頼んでくる人はプログラミング初心者**。説明は日本語で、専門用語を避けて短く。

## しくみ（3つに分かれている）

| 部分 | 置き場所 | このリポジトリのファイル |
|---|---|---|
| データ | Googleスプレッドシート（マスター。Y-PUのアカウントが持ち主） | なし（シートの見出し名がデータの形） |
| 処理（サーバー） | Google Apps Script（スプレッドシートに紐づけ）をウェブアプリとして公開 | `gas/コード.gs` |
| 画面 | GitHub Pages（`https://yypupu.github.io/yp-project1/`） | `index.html`（＋ `config.js`） |

- 画面は `fetch` で Apps Script の `/exec` に `POST {fn, args}`（Content-Type: text/plain）し、`doPost` が `API` の表から関数を呼んで `{ok, result|error}` を返す。
- `config.js` の `window.YPU_API` が Apps Script のウェブアプリURL。デプロイを「新バージョン」で更新する限り変わらない（「新しいデプロイ」を作るとURLが変わる）。
- `gas/Index.html` は Apps Script の URL から直接開いたとき用の同じ画面。`<?= apiUrl ?>` などのテンプレートが入っている。

## 絶対に守ること

1. **画面は `gas/Index.html` だけを直す。** 直したら必ず `python3 tools/build_hosted.py` で `index.html` を作り直す。`index.html` を直接直さない（2つの中身がずれる）。
2. **`gas/コード.gs` を変えたら、版を上げる。** `gas/コード.gs` と `gas/Index.html` の `APP_VERSION` を、同じ日付の文字列（例 `'2026.12.01'`）にそろえる。画面は版が違うと「サーバーが古い」と黄色い注意を出す。画面だけの変更なら版は変えない。
3. **見出し名（シートの列名）を変えない。** 列を足すときは `TABLES` の `fields` に足し、`setup()`（メニューの「初期チェック」）が足りない列を自動で足す。既存の列名を変えると本番データが読めなくなる。
4. **個人情報・秘密を入れない。** このリポジトリは Public。メールアドレス（テスト用の `*.example` 以外）、APIキー、スプレッドシートのID、名簿、クライアント名を、コード・テスト・コミットメッセージに書かない。スプレッドシートのIDは Apps Script のスクリプトプロパティ `SS_ID` にだけある。
5. **コミットの作者に個人のメールアドレスを使わない。** GitHub の noreply アドレスで。
6. **直したら `node tools/test/run-all.js` を通す。** 新しい機能には、`tools/test/` にテストを足す。

## 速さのための作り（壊さないこと）

- サーバー：1回の呼び出しでスプレッドシートを開くのは1回（`SS_`）、同じシートを読むのも1回（`MEMO_`）。あまり変わらないシート（`SHARED_`）は5分キャッシュし、手で編集されたら `onEdit` で消す。
- サーバー：データが変わったかは「版」（`ver_()`、書き込みのたびに `invalidate_()` で進む）で判断し、30秒ごとの確認（`sync`）は変わっていなければシートを読まない。
- サーバー：保存・削除は `saveRows` / `deleteRows` でまとめて1回。書いたあとは読み直さない。
- 画面：保存を待たずに画面をすぐ変え（`patch` / `addRows` / `delRows` → `enqueue`）、裏で順番に送る（`pump`）。失敗したら「もう一度／取り消す」が出る。新しい行は仮のID（`tmp…`）で出し、保存後に本物のIDへ置き換える（`TMPMAP`）。
- 画面：描き直しはページ全体を作り直さず、変わったところだけ書き換える（`morphChildren`）。変えた行だけすぐ直す（`quickRows` / `quickInsert`）、件数などは手が空いたときに（`idleRender`）。行には中身のしるし `data-h` があり、変わっていない行は比べずに飛ばす。
- 画面：一覧ははじめ50行だけ描き（`PAGE_ROWS`）、スクロールで続きを描く。追加したばかりの行（`FRESH`）は必ず描く。
- 画面：表の列幅は最初から決めている（`W`：表ごと・列ごとの幅）。列を足したら `W` にも幅を足す。

## 列のしくみ（どの表も共通）

- 表の列は `BASE`（はじめの並び）→ プロジェクトごとの設定（シート「表の設定」、`saveColCfg`）で並び・表示／非表示・自分たちで足した列が決まる。画面は `colsOf(key)` で今の列を得て、`gridStart` / `gridRow` で描く。セルの中身は `CELL[key][列]`。
- 集客アタックは種類ごとに設定が別（`cfgKey` → `'atk:企業'` など）。種類のタブは選択肢「アタック種類」。
- 自分たちで足した列は `'x:c1'` のような名前で、値は行の `ext`（シートの「追加項目」列に JSON）に入る。サーバーは送られた分だけ重ねて保存する（`mergeExt_`）。
- 選択肢は「選択肢」シート（全プロジェクト共通）。画面のプルダウンの一番下「✏️ 選択肢を編集…」→ `saveChoices`。名前を変えると入っている値も変わる（`CHOICE_USE`）。
- シート側の入力規則（プルダウン・チェックボックス）に合わない値は、保存時に規則に合わせて書き直し、合わないものは空にして `warn` で知らせる（`writeRows_`）。
- 見出しに無い列を保存すると、シートの右に列を自動で足す（`ensureHeads_`）。

## 主な場所

- `gas/コード.gs`：`TABLES`（表ごとのシート名・項目・数値/日付/時刻の列）、`API`（画面から呼べる関数の一覧）、`setup`（初期チェック）、`requestCode`/`verifyCode`（メールの6桁コードでログイン。同じアドレスへの送信は1時間に3回まで。ログインは90日、使うたびに延長）、`check_`（ページの閲覧権限）、`getProject`/`sync`/`saveRows`/`deleteRows`。
- `gas/Index.html`：`META`（表ごとの見出し・選択肢）、`FIELDS`、`BASE`/`W`/`CELL`（列のしくみ）、`alertList`（ベルのお知らせ）、`drawer`（メニュー）、`modalHtml`（項目の管理・選択肢の編集）、グラフ（`donut`/`stack`/`prog`/`barList`）、各ページの `viewXxx()`、`ACT`（ボタンの動き）、キーボード・コピー貼り付け・右クリック・スワイプの処理。
- 見た目の確認：`node tools/test/shots.js` で `tools/test/out/` に主な画面のスクリーンショットができる。

## テスト

- `tools/test/gasmock.js`：Apps Script のまね（スプレッドシート・キャッシュ・ロックなど）。`gas/コード.gs` を手元で動かす。
- `tools/test/test-data.json`：まねのスプレッドシートの中身（架空のサンプル）。
- `server.test.js`：サーバーの大事な動き。`ui-*.test.js`：本物の画面を Playwright で動かし、まねのサーバーとつないで確かめる（PC・スマホ・受付リンク・長い一覧・反応の速さ）。
- 準備：`cd tools/test && npm install && npx playwright install chromium`
- 実行：`node tools/test/run-all.js`（一部だけなら `node tools/test/run-all.js server`）
- テストは `index.html` を使うので、先に `python3 tools/build_hosted.py` を実行しておく。

## 直したあと、頼んだ人に伝えること（毎回）

- **画面だけ変えたとき**：GitHub に入れれば数分でサイトに出る。サイトを Ctrl+Shift+R（Macは⌘+Shift+R）で読み直してもらう。Apps Script の URL から直接開く人がいるなら、`gas/Index.html` の中身を Apps Script の「Index.html」に貼り付けて「新バージョン」でデプロイ。
- **サーバーも変えたとき**：上に加えて、`gas/コード.gs` の中身を Apps Script の「コード.gs」に貼り付けて保存 → スプレッドシートのメニュー「Y-PUアプリ」→「初期チェック」 → **Y-PUのアカウントで**「デプロイ」→「デプロイを管理」→ ✏️ →「新バージョン」→「デプロイ」。デプロイは必ず Y-PU のアカウントで（実行する人のアカウントでメールが送られるため）。
- 画面の一番下の「版」が新しい数字になっていれば反映できている。
