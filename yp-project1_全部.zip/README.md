# Y-PU プロジェクト運営アプリ

Y-PU ENTERTAINMENT の学生プロジェクト運営アプリです（ToDo・集客アタック・メンバー表・備品表・制作物・資料・タイムテーブル・アンケート分析・権限）。

- サイト：https://yypupu.github.io/yp-project1/
- データはすべて Y-PU の Google スプレッドシートにあります。このリポジトリには、画面とサーバーのコードだけが入っています（名簿・メールアドレス・データは入っていません）。

## しくみ

| 部分 | 場所 | 役割 |
|---|---|---|
| データ | Googleスプレッドシート（マスター） | すべての記録の保管場所 |
| 処理 | Google Apps Script（スプレッドシートに紐づけ） | ログイン、保存、メール送信、フォーム取り込み、権限チェック |
| 画面 | GitHub Pages（このリポジトリの `index.html`） | 表示だけ |

## ファイル

- `index.html`：GitHub Pages で表示する画面（`gas/Index.html` から作る。直接は直さない）
- `config.js`：Apps Script のウェブアプリURL（`…/exec`）
- `gas/コード.gs`：Apps Script の「コード.gs」に貼るコード
- `gas/Index.html`：Apps Script の「Index.html」に貼る画面。画面を直すときはこちらを直す
- `tools/build_hosted.py`：`gas/Index.html` から `index.html` を作る道具
- `tools/test/`：動作確認のテスト一式
- `CLAUDE.md`：Claude（AI）に作業を頼むときの引き継ぎメモ。人が読んでも、このアプリの決まりごとが分かります

## 使い方を変えたい・機能を足したいとき

1. Claude Code（https://claude.ai/code ・有料プラン）で、このリポジトリ `yypupu/yp-project1` を選び、「〇〇を△△にしたい」と頼みます。Claude は `CLAUDE.md` を読んでから作業します。
2. Claude が直したら、伝えられた手順で反映します。
   - 画面だけ：数分でサイトに出ます。サイトを Ctrl+Shift+R で読み直してください。
   - サーバーも：`gas/コード.gs` と `gas/Index.html` を Apps Script に貼り付け → スプレッドシートのメニュー「Y-PUアプリ」→「初期チェック」 → **Y-PUのアカウントで**「デプロイを管理」→ ✏️ →「新バージョン」でデプロイ。
3. 画面の一番下の「版」が新しくなっていれば完了です。

スプレッドシートだけで変えられること（コード不要）：選択肢（「選択肢」シート）、閲覧権限（「権限」シート）、外部アプリのリンク・フォームのURL（アプリの「権限・連携」ページ）。

## 公開の設定

- Apps Script のデプロイ：次のユーザーとして実行「自分（Y-PU）」、アクセスできるユーザー「全員」
- GitHub Pages：Settings → Pages → Branch `main` / `(root)`
